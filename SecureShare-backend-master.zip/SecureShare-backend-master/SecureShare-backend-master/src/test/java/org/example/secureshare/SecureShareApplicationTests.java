package org.example.secureshare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureShareApplicationTests {

    @Test
    void contextLoads() {
    }

}
