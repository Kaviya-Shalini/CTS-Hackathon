package org.example.secureshare.service;

import org.springframework.stereotype.Service;

@Service
public class GroupService {
}
